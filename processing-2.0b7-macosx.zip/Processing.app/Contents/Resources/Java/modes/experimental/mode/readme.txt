Packages from Eclipse 4.2.1:
http://download.eclipse.org/eclipse/downloads/

