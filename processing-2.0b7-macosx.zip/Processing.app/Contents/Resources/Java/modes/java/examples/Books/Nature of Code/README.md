# The Nature of Code

![Screenshot](http://www.shiffman.net/images/noc/1.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/2.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/3.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/4.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/5.jpg) ![Screenshot](http://www.shiffman.net/images/noc/6.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/7.jpg)  ![Screenshot](http://www.shiffman.net/images/noc/8.jpg)

# What is this?

This repository contains all of the examples for my ITP course and upcoming book "The Nature of Code."  It is currently in progress and as I write the book, I will continue to add and update the examples here. 

Relevant links:

[Site](http://www.natureofcode.com)

[Online tutorials](http://www.shiffman.net/teaching/nature/)

[2011 Syllabus](http://itp.nyu.edu/varwiki/Syllabus/Nature-of-Code-S11)
